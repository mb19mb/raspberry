  var READTHEDOCS_DATA = {
    project: "uwsgi-docs",
    version: "latest",
    language: "en",
    subprojects: {},
    canonical_url: "http://uwsgi-docs.readthedocs.io/en/latest/",
    theme: "sphinx_rtd_theme",
    builder: "sphinx",
    docroot: "/./",
    source_suffix: ".rst",
    api_host: "https://readthedocs.org",
    commit: "28b26840"
  };
  